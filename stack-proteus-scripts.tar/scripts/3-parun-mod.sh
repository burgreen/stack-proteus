#!/bin/bash

#--------------------------------------------
# goal: mod parun to lead with sbang
#
# author: greg.burgreen@msstate.edu
#         Mississippi State Univ
#         version 2019.03.27
#--------------------------------------------

#--------------------------------------------
# 1. post-install modifications to parun
#--------------------------------------------

cat > zparun << EOF
#!/bin/bash $spack_root/bin/sbang
EOF

if head -1 ./python/bin/parun | grep bash > /dev/null 2>&1; then

cat >> zparun << EOF
$(sed 1,1d ./python/bin/parun)
EOF

else

cat >> zparun << EOF
$(cat ./python/bin/parun)
EOF

fi

chmod +x zparun

mv zparun ./python/bin/parun
