#!/bin/bash

set -e

#--------------------------------------------
# goal: build Proteus using Spack
#
# author: greg.burgreen@msstate.edu
#         Mississippi State Univ, April 03, 2019
#--------------------------------------------
  
python_ver=python3.7

script_dir=$(cd "$(dirname "$0")"; pwd)
spack_dir=$script_dir/..

module purge

#source $script_dir/../1-setup-spack.sh
source $script_dir/../2-setup-compiler.sh

spack_compiler=$(echo $spack_compiler | sed -e "s/@/-/")

echo Proteus-stack compiler: $spack_compiler

#--------------------------------------------
# 1. modify proteus source files
#--------------------------------------------

# a. rename macro in proteus/mprans/SW2DCV.h

#sw2dcv_h=$(find . -name SW2DCV.h)
#
#if [ ! -f $sw2dcv_h-orig ]; then
#
#  cp $sw2dcv_h $sw2dcv_h-orig
#
#  echo - modifying $sw2dcv_h
#
#  sed -i -e 's/ f(g/ fxx(g/g' $sw2dcv_h
#
#fi

# b. comment out MACOSX in proteus/config/default.py

default_py=$(find . -name default.py)

if [ $(find . -name default.py | wc -l) -ne "1" ]; then
    echo Need to "./make.sh clean" first for a complete rebuild.
    exit
fi

if [ ! -f $default_py-orig ]; then

  cp $default_py $default_py-orig

  echo - modifying $default_py

  sed -i -e 's/ os.env/ #os.env/g' $default_py
  sed -i -e 's/linux2/linux/g' $default_py

fi

#--------------------------------------------
# 2. write 2-makefile
#--------------------------------------------

install_dir=$(pwd)/python/lib/$python_ver/site-packages

cat > 2-makefile << EOF
.PHONY: all clean

all: spack 

PROTEUS_DEVELOP_CMD = pip --disable-pip-version-check install -v -e .

PROTEUS_DIR=$(pwd)

PROTEUS_FLAGS ?="-Wall -Wstrict-prototypes -DDEBUG -Og"

clean:
	python setup.py clean
	rm -rf build
	rm -rf dist
	rm -rf proteus.egg-info
	rm -rf bin 
	rm -rf python
	rm 0-README.md
	rm 1-module-load-proteus.sh
	rm 2-makefile
	rm 3-parun-mod.sh
	rm make.sh

spack:
	mkdir -p python/bin
	mkdir -p python/lib/$python_ver/site-packages
	mkdir -p bin
	CFLAGS=\${PROTEUS_FLAGS} \${PROTEUS_DEVELOP_CMD}
	python setup.py build_ext
	python setup.py install --prefix=\${PROTEUS_DIR}/python
	cd scripts && PROTEUS_PREFIX=\${PROTEUS_DIR} make
	./3-parun-mod.sh
	./4-chmod-python.sh

EOF

#--------------------------------------------
# 3. write 1-module-load-proteus.sh
#--------------------------------------------

cp $spack_dir/4-module-load-proteus.sh ./1-module-load-proteus.sh
cp $spack_dir/5-chmod-python.sh ./4-chmod-python.sh

cat >> 1-module-load-proteus.sh << EOF

export PATH=$(pwd)/python/bin:\$PATH
export PYTHONPATH=$install_dir:\$PYTHONPATH
export PYTHONPATH=$(pwd)/python/bin:\$PYTHONPATH

EOF

chmod +x  1-module-load-proteus.sh
chmod +x  4-chmod-python.sh

#--------------------------------------------
# 4. build proteus
#--------------------------------------------

cp $script_dir/3-parun-mod.sh .

echo "source ./1-module-load-proteus.sh"
source ./1-module-load-proteus.sh
echo $PYTHONPATH

# the gcc@spack compiler requires this H5public.h mod
#echo " - applying thirdparty/hdf5_fix/mod"
#cp $spack_dir/thirdparty/hdf5_fix/H5public-mod.h $hdf5_dir/include/H5public.h

make -f 2-makefile

# undo the H5public.h mod
#echo " - applying thirdparty/hdf5_fix/orig"
#cp $spack_dir/thirdparty/hdf5_fix/H5public-orig.h $hdf5_dir/include/H5public.h

#--------------------------------------------
# 5. post-install modifications to parun
#--------------------------------------------

cat > zparun << EOF
#!/bin/bash $spack_dir/bin/sbang
EOF

if head -1 ./python/bin/parun | grep bash > /dev/null 2>&1; then

cat >> zparun << EOF
$(sed 1,1d ./python/bin/parun)
EOF

else

cat >> zparun << EOF
$(cat ./python/bin/parun)
EOF

fi

chmod +x zparun

mv zparun ./python/bin/parun

#--------------------------------------------
# 6. post-install create make.sh script
#--------------------------------------------

cat > make.sh << EOF
#!/bin/bash

# goal: make script for Spack-based Proteus

what=\$1

if [ -z "\$1" ]; then 
  what=spack
fi

echo make -f ./2-makefile \$what

if [ -z "\$spack_root" ]; then 
  echo - First, executing: source ./1-module-load-proteus.sh
  echo - You can prevent this by executing this command in your shell
  echo 
  source ./1-module-load-proteus.sh
fi

make -f ./2-makefile \$what

EOF

chmod +x make.sh

#--------------------------------------------
# 7. write 0-README.md
#--------------------------------------------

cat > ./0-README.md << EOF

**To rebuild this version of Proteus:** 

$ source \<proteus_dir\>/1-module-load-proteus.sh    # needed only once per session

- Revise the source code. 

$ ./make.sh 

**To rebuild this version of Proteus against a different Proteus stack:**

$ source \<proteus_dir\>/1-module-load-proteus.sh    # needed only once per session

$ ./make.sh clean

$ \<different_stack_dir\>/scripts/build-proteus.sh 
 
**To execute this version of Proteus:**

$ source \<proteus_dir\>/1-module-load-proteus.sh    # needed only once per session

$ cd \<case_dir\>

$ which parun   # just for confirmation

$ parun ...

**To share the Proteus stack or Proteus builds, simply change directory access privileges.**

$ chmod 777 \<stack_dir\> \<proteus_dir\>

- built with Proteus stack in: $spack_dir
EOF

#--------------------------------------------
# 8. print final user info
#--------------------------------------------

echo ------------------------------------------
echo
echo Proteus build is complete and successful.
echo
echo ------------------------------------------
echo To run this version of proteus:
echo source $(pwd)/1-module-load-proteus.sh
echo parun ...
echo
echo To rebuild this version of proteus:
echo source $(pwd)/1-module-load-proteus.sh
echo ./make.sh
echo
echo Read ./0-README.md for more information. 
echo ------------------------------------------

chmod 700 *
chmod -R 755 bin python scripts proteus.egg-info
chmod 777 1-module-load-proteus.sh 2-makefile make.sh 

