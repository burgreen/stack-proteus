#!/bin/bash

#set -x
#set -e

#--------------------------------------------
# purpose: install software stack for proteus
#
# author: greg.burgreen@msstate.edu
#         Mississippi State Univ
#         version 2019.02.11
#--------------------------------------------

#if [ -z "$1" ]; then 
#  echo
#  echo usage: $0 \<compiler\>
#  echo
#  echo where \<compiler\> is a compiler known to
#  echo successfully install a Spack package.
#  echo
#  echo For example, $0 gcc@5.3.0
#  exit
#fi

echo -----------------------------------------------
echo Executing ./scripts/install-stack-proteus.sh 
echo -----------------------------------------------

#--------------------------------------------
# 1. unarchive tarballs
#--------------------------------------------

# do this else where 

#stack_thirdparty=stack-proteus-thirdparty.tar
#stack_var=stack-proteus-var.tar

#tar xfv $stack_thirdparty
#tar xfv $stack_var

#--------------------------------------------
# 2. prelims
#--------------------------------------------

if [ ! -f ./1-setup-spack.sh ]; then
   echo Error: Missing 1-setup-spack.sh
   echo Follow instructions at github.com/burgreen/stack-spack
   exit
fi

if [ ! -f ./2-setup-compiler.sh ]; then
   echo Error: Missing 2-setup-compiler.sh
   echo Did you ./scripts/compiler.sh finalize \<compiler\>\?
   exit
fi

source ./1-setup-spack.sh
source ./2-setup-compiler.sh

compiler=$spack_compiler

echo Using compiler: $compiler

cat > etc/spack/packages.yaml << EOF
packages:
  all:
    providers:
      mpi: [mpich, openmpi]
      jpeg: [libjpeg, openjpeg]
EOF

#--------------------------------------------
# 3. install most of proteus stack
#--------------------------------------------

#source ./scripts/install-prep.sh

spack install proteus-stack %$compiler
spack install ann %$compiler

#--------------------------------------------
# 4. install some extra needed pieces
#--------------------------------------------

# a. py-tables

# should already be present. here are command just in case
#spack load mpi 
#spack load py-pip 
#spack load py-setuptools
#spack load py-numexpr
#spack load py-numpy
#spack load py-six
#spack load py-nose 
#hdf5_dir=$(spack location -i hdf5)
#export HDF5_DIR=$hdf5_dir
#pip install ./thirdparty/tables-3.4.3.tar.gz

# b. py-recordtype

# should already be present. here are command just in case
#spack load py-pip
#spack load py-setuptools
#pip install ./thirdparty/recordtype-1.1.tar.gz

#--------------------------------------------
# 5. write 4-module-load-proteus.sh
#--------------------------------------------

spack_compiler=$(echo $spack_compiler | sed -e "s/@/-/")

cat > 4-module-load-proteus.sh << EOF
#!/bin/bash

source $SPACK_ROOT/2-setup-compiler.sh

export spack_root=$SPACK_ROOT

export CHRONO_DIR=$(spack location -i chrono)

export hdf5_dir=$(spack location -i hdf5) 

export PYTHONPATH=$SPACK_ROOT/lib/spack

export PYTHONPATH=$(spack location -i python)/bin:\$PYTHONPATH

echo Running 1-module-load-proteus.sh
echo  - loading lots of modules...

$(spack module tcl loads | grep -v \# | grep $spack_compiler)
$(spack module tcl loads | grep -v \# | grep binutils)

EOF

chmod +x 4-module-load-proteus.sh

#--------------------------------------------
# 6. finales
#--------------------------------------------

echo ------------------------------------------------------
echo Installing ./scripts/install-proteus-stack.sh is done
echo ------------------------------------------------------

num_expected=70
num_pkg=$(spack find | wc -l)

if [ "$num_pkg" -lt "$num_expected" ]; then
   echo
   echo -----------------------------------------------
   echo WARNING: There are too few installed packages.
   echo Something during the build has gone wrong.
   echo Scroll up though the build log and look for errors.
   echo 
   echo DO NOT PROCEED TO THE BUILD PROTEUS STEP.
   echo -----------------------------------------------
fi

chmod 700 *
chmod -R 777 bin share opt scripts
chmod 700 bin/*
chmod 700 scripts/*
chmod 777 0-README.md 2-setup-compiler.sh bin/sbang scripts/build-proteus.sh

#set +e
#set +x
