##############################################################################
# Copyright (c) 2013-2018, Lawrence Livermore National Security, LLC.
# Produced at the Lawrence Livermore National Laboratory.
#
# This file is part of Spack.
# Created by Todd Gamblin, tgamblin@llnl.gov, All rights reserved.
# LLNL-CODE-647188
#
# For details, see https://github.com/spack/spack
# Please also see the NOTICE and LICENSE files for our notice and the LGPL.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License (as
# published by the Free Software Foundation) version 2.1, February 1999.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the IMPLIED WARRANTY OF
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the terms and
# conditions of the GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
##############################################################################

# created 2018.04.19 by greg.burgreen@msstate.edu for the Proteus project

from spack import *

class Chrono(CMakePackage):
    """A C++ library for multi-physics simulation"""
    homepage = "http://projectchrono.org"
    url      = "https://github.com/projectchrono/chrono/archive/3.0.0.tar.gz"

    #burgreen version('3.0.0', '6518d6c176ba6f93dcd92a0e88608b9c')
    version('3.0.99', 'f6ddf60fdf31df624b3158791b12175f') # commit f21f02b

    # Required dependencies
    depends_on('cmake')
    depends_on('bzip2')
    depends_on('python')
    depends_on('zlib')
    depends_on('openjpeg')
    depends_on('libjpeg')
    depends_on('swig')
    depends_on('blaze')
    depends_on('boost')
    depends_on('mpi')

    # Optional dependencies
    # todo depends_on("mpi", when="+mpi")

    # Patches
    #burgreen patch('lib64.patch')

    def cmake_args(self):
        spec = self.spec
        options = []

        options.extend([
          '-DCMAKE_BUILD_TYPE:STRING=Debug',
          '-DENABLE_UNIT_CASCADE:BOOL=ON',
          '-DENABLE_MODULE_FEA:BOOL=ON',
          '-DENABLE_MODULE_POSTPROCESS:BOOL=ON',
          '-DENABLE_MODULE_VEHICLE:BOOL=ON',
          '-DENABLE_MODULE_FSI:BOOL=ON',
          '-DENABLE_OPENMP:BOOL=ON',
          '-DUSE_PARALLEL_SIMD:BOOL=ON'
          '-DENABLE_MODULE_IRRLICHT:BOOL=OFF',
          '-DENABLE_MODULE_PYTHON:BOOL=OFF',
          '-DENABLE_MODULE_COSIMULATION:BOOL=OFF',
          '-DENABLE_MODULE_MATLAB:BOOL=OFF',
          '-DENABLE_MODULE_MKL:BOOL=OFF',
          '-DENABLE_MODULE_PARALLEL:BOOL=OFF',
          '-DENABLE_MODULE_OPENGL:BOOL=OFF',
          '-DENABLE_MODULE_OGRE:BOOL=OFF',
          '-DBLAZE_DIR:PATH={0}'.format(spec['blaze'].prefix.include),
          '-DBOOST_DIR:PATH={0}'.format(spec['boost'].prefix.include)
        ])

        python_exe     = spec['python'].command.path
        python_library = spec['python'].libs[0]
        python_include = spec['python'].headers.directories[0]
        options.extend([
          '-DPYTHON_EXECUTABLE=%s'  % python_exe,
          '-DPYTHON_INCLUDE_DIR=%s' % python_include,
          '-DPYTHON_LIBRARY=%s'     % python_library
        ])

        return options
