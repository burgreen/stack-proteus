##############################################################################
# Copyright (c) 2013-2018, Lawrence Livermore National Security, LLC.
# Produced at the Lawrence Livermore National Laboratory.
#
# This file is part of Spack.
# Created by Todd Gamblin, tgamblin@llnl.gov, All rights reserved.
# LLNL-CODE-647188
#
# For details, see https://github.com/spack/spack
# Please also see the NOTICE and LICENSE files for our notice and the LGPL.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License (as
# published by the Free Software Foundation) version 2.1, February 1999.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the IMPLIED WARRANTY OF
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the terms and
# conditions of the GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
##############################################################################

# created 2018.04.19 by greg.burgreen@msstate.edu for the Proteus project

import os
import glob
import shutil
from spack import *

class Daetk(MakefilePackage):
    """The Differential Algebraic Equation Toolkit from ERDC"""
    homepage = "https://github.com/erdc/daetk"
    url      = "https://github.com/erdc-cm/daetk/archive/1.0.0.tar.gz"

    # update burgreen 2019.02.13
    version('1.0.1', '8bf2fff73c2c9f30b527cead1064c87a')

    # Required dependencies
    depends_on('petsc')
    depends_on('parmetis')
    depends_on('mpi')

    def setup_environment(self, spack_env, run_env):

        arch = 'linux'
        if 'darwin' in self.spec.architecture: arch = 'darwin'

        #export DAETK_DIR=`pwd`
        #export DAETK_ARCH=linux
        #export PETSC_DIR=$PETSC_DIR
        # already set spack_env.set('PETSC_DIR', self.spec['petsc'].prefix)
        #export PETSC=$PETSC_DIR
        #export MPI=$MPI_DIR
        spack_env.set('DAETK_DIR', '.')
        spack_env.set('DAETK_ARCH', arch)
        spack_env.set('PETSC', self.spec['petsc'].prefix)
        spack_env.set('MPI', self.spec['mpi'].prefix)
        spack_env.set('SPACK_DAETK', self.spec['daetk'].prefix)
        
    def edit(self, spec, prefix):

        pkg_dir = os.path.dirname(self.module.__file__)
        build_dir = self.stage.source_path

        arch = 'linux'
        if 'darwin' in self.spec.architecture: arch = 'darwin'

        if arch == 'linux':
          #cp _hashdist/arch.linux config/linux
          file_src = join_path( pkg_dir, 'arch.linux')
          file_dst = join_path( build_dir, 'config', 'linux')
          shutil.copy(file_src, file_dst)
          #cp _hashdist/archive.linux config/linux.archive
          file_src = join_path( pkg_dir, 'archive.linux')
          file_dst = join_path( build_dir, 'config', 'linux.archive')
          shutil.copy(file_src, file_dst)
          #cp _hashdist/sources.linux config/linux.sources
          file_src = join_path( pkg_dir, 'sources.linux')
          file_dst = join_path( build_dir, 'config', 'linux.sources')
          shutil.copy(file_src, file_dst)

        if arch == 'darwin':
          #cp _hashdist/arch.darwin config/darwin
          file_src = join_path( pkg_dir, 'arch.darwin')
          file_dst = join_path( build_dir, 'config', 'darwin')
          shutil.copy(file_src, file_dst)
          #cp _hashdist/archive.darwin config/darwin.archive
          file_src = join_path( pkg_dir, 'archive.darwin')
          file_dst = join_path( build_dir, 'config', 'darwin.archive')
          shutil.copy(file_src, file_dst)
          #cp _hashdist/sources.darwin config/darwin.sources
          file_src = join_path( pkg_dir, 'sources.darwin')
          file_dst = join_path( build_dir, 'config', 'darwin.sources')
          shutil.copy(file_src, file_dst)
          #patch -p1 < _hashdist/remove_fortran_dependencies.patch
          # this seems not to be needed, famous last words

        touch( join_path(build_dir,'dep.txt'))

    def build(self, spec, prefix):

        make('all')

    def install(self, spec, prefix):

        # yaml
        #mkdir $ARTIFACT/lib
        #cp libdaetk.* $ARTIFACT/lib

        mkdirp(prefix.lib)
        lib_files  = glob.glob('lib*.a')
        lib_files += glob.glob('lib*.so')
        lib_files += glob.glob('lib*.dylib')
        for file in lib_files: install(file, prefix.lib)

        # yaml
        #mkdir $ARTIFACT/include
        #cp *.h $ARTIFACT/include
        #cp -r pete/pete-2.1.0/src/PETE $ARTIFACT/include

        mkdirp(prefix.include)
        #install_tree('include', prefix.include)
        inc_files  = glob.glob('*.h')
        for file in inc_files: install(file, prefix.include)

        pete_dir = join_path( prefix.include, 'PETE' )
        pete_files = glob.glob(join_path('pete/pete-2.1.0/src/PETE/*.h'))
        mkdirp( pete_dir )
        for file in pete_files: install(file, pete_dir )
