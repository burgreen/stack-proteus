##############################################################################
# Copyright (c) 2013-2018, Lawrence Livermore National Security, LLC.
# Produced at the Lawrence Livermore National Laboratory.
#
# This file is part of Spack.
# Created by Todd Gamblin, tgamblin@llnl.gov, All rights reserved.
# LLNL-CODE-647188
#
# For details, see https://github.com/spack/spack
# Please also see the NOTICE and LICENSE files for our notice and the LGPL.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License (as
# published by the Free Software Foundation) version 2.1, February 1999.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the IMPLIED WARRANTY OF
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the terms and
# conditions of the GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
##############################################################################

# developed on 2018.05.21 by greg.burgreen@msstate.edu

import os
import glob
import shutil
import subprocess

from spack import *

class ProteusStack(Package):
    """stack required by Proteus"""

    homepage = "http://www.generic.org/"

    version('1.0', url="file://%s/proteus-stack.tar" % os.getcwd())

    #variant('stdbool_fix', default=False, description='handle hdf H5public.h issues')

    # required dependencies for proteus-lib
    depends_on('gmp')
    depends_on('python')
    #depends_on('proteus-gmsh')
    depends_on('gmsh')
    depends_on('tetgen')
    depends_on('triangle-lib')
    depends_on('daetk')
    depends_on('superlu')
    depends_on('chrono')
    depends_on('scorec-core-cache')

    # burgreen 2019.02.13
    depends_on('py-petsc4py@3.10.99')
    # py-petsc4py will install:
    #depends_on('py-setuptools', type='build')
    #depends_on('py-numpy')
    #depends_on('py-mpi4py')

    # required dependencies for py-proteus
    #depends_on('py-setuptools', type='build')
    depends_on('py-cython')
    #depends_on('py-numpy')
    depends_on('py-h5py') # modified py-pkgconfig to make this work

    # running parun will require, at least
    #depends_on('py-mpi4py')
    #depends_on('py-petsc4py')
    depends_on('py-scipy')
    depends_on('py-numexpr') # Python tables

    # required dependencies for proteus-exe
    depends_on('py-pip')
    depends_on('py-six')
    depends_on('py-nose')
    depends_on('py-future') 

    def setup_environment(self, spack_env, run_env):

        spack_env.set('HDF5_DIR', self.spec['hdf5'].prefix )
        print( self.spec['hdf5'].prefix )

    def install( self, spec, prefix ):

        #pkg_dir = os.path.dirname(self.module.__file__)
        #stdbool_fix_dir = spack_dir + os.sep + 'thirdparty/stdbool_fix'
        #build_dir = self.stage.source_path
        #hdf5_include_dir = spec['hdf5'].prefix.include

        #if '+stdbool_fix' in spec:
        #   file_src = join_path( stdbool_fix_dir, 'H5public-orig.h')
        #   file_dst = join_path( hdf5_include_dir, 'H5public.h')
        #   shutil.copy(file_src, file_dst)

        spack_dir = os.getenv('SPACK_ROOT')

        pkgs = []
        pkgs.append('thirdparty/recordtype/py-recordtype-1.3.tar.gz')
        pkgs.append('thirdparty/tables/py-tables-3.4.4.tar.gz')

        for pkg in pkgs:
          cmd = 'pip install ' +  spack_dir + os.sep + pkg
          print(cmd)
          subprocess.call( cmd, shell=True)

        install('spack-build.out', prefix )

