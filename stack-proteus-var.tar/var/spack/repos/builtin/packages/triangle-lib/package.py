##############################################################################
# Copyright (c) 2013-2018, Lawrence Livermore National Security, LLC.
# Produced at the Lawrence Livermore National Laboratory.
#
# This file is part of Spack.
# Created by Todd Gamblin, tgamblin@llnl.gov, All rights reserved.
# LLNL-CODE-647188
#
# For details, see https://github.com/spack/spack
# Please also see the NOTICE and LICENSE files for our notice and the LGPL.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License (as
# published by the Free Software Foundation) version 2.1, February 1999.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the IMPLIED WARRANTY OF
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the terms and
# conditions of the GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
##############################################################################

# created by greg.burgreen@msstate.edu

import os
import glob
import shutil
from spack import *

class TriangleLib(MakefilePackage):
    """An ERDC modified version of Triangle"""

    url = "https://github.com/erdc-cm/triangle/archive/master.zip"

    version('1.6', '21d710cd7ae24b665061a2acc25446be')

    def setup_environment(self, spack_env, run_env):

        spack_env.set('TRIANGLE_ARCH', 'linux')

    def edit(self, spec, prefix):

        pkg_dir = os.path.dirname(self.module.__file__)
        build_dir = self.stage.source_path

        file_src = join_path(   pkg_dir, 'makefile.linux')
        file_dst = join_path( build_dir, 'makefile.linux')
        shutil.copy(file_src, file_dst)

        file_src = join_path(   pkg_dir, 'makefile.darwin')
        file_dst = join_path( build_dir, 'makefile.darwin')
        shutil.copy(file_src, file_dst)

    def build(self, spec, prefix):

        make('--makefile=makefile.linux')

    def install(self, spec, prefix):

        mkdirp(prefix.bin)
        install('bin/triangle', prefix.bin)
        install('bin/tricall', prefix.bin)

        mkdirp(prefix.lib)
        lib_files  = glob.glob('lib/lib*.a')
        lib_files += glob.glob('lib/lib*.so')
        lib_files += glob.glob('lib/lib*.dylib')
        for file in lib_files: install(file, prefix.lib)

        mkdirp(prefix.include)
        inc_files  = glob.glob('src/*.h')
        for file in inc_files: install(file, prefix.include)
